package energium;

public final class IOConstants {
    public static final String DONE = "D_DONE";
    public static final String TILE_POINTS = "t";
    public static final String BASE_LOCATION = "b";
    public static final String TEAM_POINTS = "p";
    public static final String UNIT_DATA = "u";
}